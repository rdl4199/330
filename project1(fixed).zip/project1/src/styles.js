document.addEventListener('DOMContentLoaded', () =>{
    const navBurger = document.querySelector('.navbar-burger');
    const menu = document.querySelector('#main-menu');

    navBurger.onclick = ()=>{
        menu.classList.toggle('is-active');
    }

})